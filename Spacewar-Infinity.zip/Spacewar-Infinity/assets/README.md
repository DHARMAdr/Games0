# assets/
Spacewar Infinity needs **no external assets**: every ship, planet, nebula and effect is drawn procedurally on the Canvas / with CSS, and every sound is generated with the Web Audio API.
This folder is reserved for optional extras you may add later (e.g. your own images or sound files).
