# SPACEWAR INFINITY
*Defend the galaxy. Survive the infinite.*

A complete 2D space shooter made only with **HTML5, CSS3, vanilla JavaScript (ES6), Canvas and the Web Audio API**. No frameworks, no engines, no backend, no external assets, no build step.

## Features
- Cinematic main menu (10 working buttons), animated CSS + canvas starfields, nebulae, rotating planets, title reveal.
- **12-level campaign in 4 worlds** + 4 boss fights (Solar Warden, Nebula Serpent, Abyssal Dreadnought, Infinity Overlord) + **Endless Survival** (unlocks after Level 3).
- **5 ships** (Interceptor, Defender, Destroyer, Phantom, Nova) with real stat differences; buy them in the Hangar.
- **12 weapons:** Laser, Twin, Triple, Spread, Plasma, Railgun, Chain Lightning, Charged Beam, Explosive Rockets, Orbit Drones (cycle with R) + Homing Missiles (E) + Nova Blast (special ability). Weapons level up to 5. Energy/ammo limits; the Laser always works.
- **10 enemy types** with state-machine AI; telegraphed boss attacks, vulnerable windows, phases, defeat animations.
- 6 special abilities (EMP, Energy Shield, Time Warp, Overdrive, Nova Bomb, Emergency Repair) and 12 pick-ups.
- 10 upgrade lines x 5 levels (all change real game values), missions, achievements, combo multiplier, ratings (C–S), credits.
- Full settings (≈40 options) saved in localStorage and validated; remappable keys; touch joystick + buttons; gamepad; pause, restart and confirmation dialogs.
- Procedural sound effects and ambient music (Web Audio) with volume sliders and per-group toggles.

## Run it
1. Unzip the folder.
2. **Double-click `index.html`** (Chrome, Edge, Firefox, Safari). No server needed — scripts are classic `<script>` tags, not modules.
3. Optional: serve it (`python3 -m http.server`) and open `http://localhost:8000`.
Sound starts after your first click/key press (browser rule).

## Folder structure
```
Spacewar-Infinity/
├── index.html            page structure: canvas, HUD, touch controls, script order
├── README.md
├── css/  style.css (base, a11y modes) · menu.css (menus) · game.css (HUD, touch) · effects.css (CSS space, flash, scanlines)
├── js/   storage.js   creates global SW + safe localStorage save/load
│         settings.js  SCHEMA table of all options, validation, apply()
│         audio.js     Web Audio sfx + music (throttled)
│         controls.js  keyboard/mouse/touch/gamepad -> actions, key remapping
│         particles.js SW.FX (pooled particles, text, lightning) + SW.BG (parallax background)
│         weapons.js   weapon definitions
│         player.js    ships, upgrades, player update/draw
│         enemies.js   10 enemy types + AI
│         bosses.js    4 bosses (patterns, phases, telegraphs)
│         levels.js    12 levels, wave generator, missions, achievements
│         game.js      loop, state, collisions, pickups, abilities, HUD, level flow
│         ui.js        all menu screens   ·   main.js  boot
└── assets/README.md      (no assets required)
```
Script order matters (each file only uses files above it): storage → settings → audio → controls → particles → weapons → player → enemies → bosses → levels → game → ui → main.

## Controls (defaults; remap in CONTROLS)
Move W/A/S/D or arrows · Fire Space · Missile E · Special Q · Dash Left Shift · Pause Esc · Auto-fire F · Cycle weapon R (or mouse wheel) · Cycle ability C · Confirm Enter.
Mouse: left fire, right missile, optional pointer steering. Touch: left-side joystick + FIRE / SPECIAL / DASH / MISSILE. Gamepad: stick, A fire, B missile, X special, RB dash, Start pause. The "Map (M)" key from the brief is not used (no map in this game).

## Settings
SETTINGS lists Gameplay, Audio, Graphics, Controls and Accessibility groups. Every change applies immediately and is saved; APPLY saves and goes back, RESET DEFAULTS restores them, ERASE SAVE wipes progress.

## How to extend
- **New enemy:** add a row to `SW.Enemies.T` (hp, r, speed, score, credits, colour, outline `pts`), add a `case` in `SW.Enemies.update`, put its name in a level `pool` and give it a cost in `SW.Levels.COST`.
- **New level:** push `{n,w,pool,waves,env,boss?}` to `SW.LEVELS` (`w` = world index 0-3; `env` = none|asteroids|storm|gravity). Raise the `Math.min(12,...)` caps in storage.js/game.js/ui.js if you go beyond 12.
- **New weapon:** add an entry to `SW.Weapons.defs` (`name, rate, col, fire(g,p,m)`; use `g.pShot(x,y,vx,vy,dmg,{r,pierce,splash,homing,accel,life})`) and add its id to `SW.Weapons.order`.
- **New boss:** add an entry to `SW.Bosses.D` (hp, size, `phases`, `move`, `pats`, `draw`) and set `boss:'id'` on a level.
- **Difficulty:** edit `SW.Game.DIF` (hp, dmg, fire interval, speed multipliers), `SW.Levels.wave` (budget formula), enemy `T` stats, or upgrade/ship tables in `player.js`.

## Verification done
A scripted headless simulation (Node with a fake DOM) played all 12 levels, all bosses and endless mode, and checked: menus build, level unlocks only on completion, pause freezes time, restart keeps a single loop and clears entities, bullet pools stay capped, settings/save corruption is handled, key rebinding rejects duplicates, upgrades/ships change real stats, game over saves a score, all weapons/abilities/pick-ups/enemy types run. **It was not tested in a real browser or on a physical phone**, so please playtest and report/tune anything odd.

## Known limitations
- Scores are stored only in this browser (not an online leaderboard, not cheat-proof).
- Ship art is procedural (no sprite sheets); "Reposition touch controls" is not implemented (they can be forced on/off in Settings).
- Balance (damage, costs, boss HP) is a first pass — tune the tables listed above.
- Audio is synthesized, so it is simple/chip-style.
